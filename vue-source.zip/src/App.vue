<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
const baseUrl = import.meta.env.BASE_URL
const digits = ref([1, 6, 8])
const store = ref('')
const customer = ref('')
const eligible = ref(false)
const spinning = ref(false)
const ready = ref(false)
const dragging = ref(false)
const pull = ref(0)
let pointerId = null
let startY = 0
let pullDistance = 60
function unlock() {
  if (spinning.value || ready.value || !form.value.reportValidity()) return
  if (won.value) digits.value = [1, 6, 8]
  ready.value = true
  won.value = false
  message.value = '拉桿已解鎖，請按住圓球往下拉！'
}
function beginPull(event) {
  if (!ready.value || spinning.value || pointerId !== null || event.button !== 0) return
  pointerId = event.pointerId
  startY = event.clientY
  pullDistance = Math.max(35, event.currentTarget.getBoundingClientRect().height * 0.35)
  dragging.value = true
  event.currentTarget.setPointerCapture(pointerId)
}
function movePull(event) {
  if (event.pointerId !== pointerId) return
  pull.value = Math.max(0, Math.min(1, (event.clientY - startY) / pullDistance))
}
function endPull(event) {
  if (event.pointerId !== pointerId) return
  const complete = event.type === 'pointerup' && pull.value >= 0.85
  pointerId = null
  dragging.value = false
  if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId)
  pull.value = 0
  if (complete) spin()
}
function keyboardPull(event) {
  if (event.repeat || !ready.value || spinning.value) return
  spin()
}
const active = ref([false, false, false])
const message = ref('')
const won = ref(false)
const form = ref(null)
const timers = new Set()
function later(fn, delay) {
  const id = setTimeout(() => { timers.delete(id); fn() }, delay)
  timers.add(id)
}
function spin() {
  if (!ready.value || spinning.value) return
  ready.value = false
  spinning.value = true
  won.value = false
  message.value = '好運轉動中…'
  active.value = [true, true, true]
  // Demo: every whole-dollar amount from 000 to 999 is equally likely.
  const result = Math.floor(Math.random() * 1000)
  const target = String(result).padStart(3, '0').split('').map(Number)
  function tick() {
    digits.value = digits.value.map((digit, i) => active.value[i] ? (digit + 1) % 10 : digit)
    if (spinning.value) later(tick, 65)
  }
  tick()
  target.forEach((digit, i) => later(() => {
    active.value[i] = false
    digits.value[i] = digit
    if (i === 2) {
      spinning.value = false
      won.value = true
      message.value = `恭喜 ${customer.value.trim()}！獲得 ${result} 元折價金`
      store.value = ''
      customer.value = ''
      eligible.value = false
    }
  }, 1600 + i * 700))
}
const lifecycle = new AbortController()
onMounted(() => {
  const context = document.modelContext
  if (!context?.registerTool) return
  try {
    Promise.resolve(context.registerTool({
      name: 'read_slot_status',
      description: 'Read the visible slot digits and whether the game is spinning.',
      inputSchema: { type: 'object', properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: true },
      execute(input) {
        if (!input || typeof input !== 'object' || Object.keys(input).length) throw new Error('Expected an empty object')
        return { digits: digits.value.join(''), spinning: spinning.value, unlocked: ready.value, completed: won.value }
      }
    }, { signal: lifecycle.signal })).catch(() => {})
  } catch { /* Browsers without WebMCP still support the full game. */ }
})
onBeforeUnmount(() => { timers.forEach(clearTimeout); lifecycle.abort() })
</script>

<template>
  <main class="page">
    <div class="stage-wrap">
      <section class="stage" aria-label="Homelike 喜家居開幕同樂拉霸遊戲" :class="{ spinning, won }">
        <img class="background" :src="`${baseUrl}background.jpg`" alt="Homelike 喜家居 開幕同樂。滿萬元玩拉霸抽折價金，9/24 至 11/2，全台實體門市同步活動。" draggable="false">
        <div class="reels" role="img" :aria-label="`拉霸數字 ${digits.join('')}`">
          <div v-for="(digit, i) in digits" :key="i" class="reel" :class="{ rolling: active[i] }"><span>{{ digit }}</span></div>
        </div>
        <button class="lever" :class="{ unlocked: ready, dragging }" type="button" aria-label="拉下拉桿開始抽獎（可按向下鍵）" :disabled="!ready || spinning"
          @pointerdown.prevent="beginPull" @pointermove="movePull" @pointerup="endPull" @pointercancel="endPull" @lostpointercapture="endPull" @keydown.down.prevent="keyboardPull">
          <svg viewBox="0 0 160 410" aria-hidden="true"><path :d="`M8 376 H36 L${70 - pull * 20} ${108 + pull * 200}`" fill="none" stroke="#0b1530" stroke-width="25" stroke-linecap="round" stroke-linejoin="round"/><circle :cx="83 - pull * 20" :cy="70 + pull * 200" r="56" fill="#E09C8B"/><circle :cx="72 - pull * 20" :cy="51 + pull * 200" r="23" fill="#F0EED2"/></svg>
        </button>
        <form ref="form" class="entry-form" @submit.prevent="unlock">
          <div class="fields">
            <select v-model="store" aria-label="門市據點（必填）" required :disabled="spinning || ready">
              <option value="" label=" "></option>
              <option v-for="name in ['新北板橋誠品店', '新北中和特力店', '桃園店', '台中南屯店', '台南仁德店', '高雄左營店', '高雄鳳山特力店', '屏東特力店']" :key="name" :value="name">{{ name }}</option>
            </select>
            <input v-model="customer" aria-label="顧客姓名（必填）" placeholder="顧客姓名（必填）" required :disabled="spinning || ready" maxlength="40" pattern=".*\S.*" autocomplete="name">
          </div>
          <div class="actions">
            <label class="consent"><input v-model="eligible" type="checkbox" required :disabled="spinning || ready"><span>我已在實體門市消費滿10,000元</span></label>
            <button class="play" type="submit" :disabled="spinning || ready">{{ spinning ? 'GOOD LUCK!' : 'READY TO PLAY!' }}</button>
          </div>
        </form>
        <p class="status" :class="{ success: won }" role="status" aria-live="polite">{{ message }}</p>
        <div v-if="won" class="confetti" aria-hidden="true"><i v-for="n in 90" :key="n" :style="{ '--i': n, '--x': `${(n * 37) % 101}%`, '--drift': `${((n * 19) % 25) - 12}cqw`, '--delay': `${(n % 18) * 0.055}s`, '--duration': `${2.8 + (n % 9) * 0.18}s`, '--turn': `${(n % 2 ? 1 : -1) * (360 + n * 17)}deg`, '--color': ['#FF4F81', '#FFD447', '#35D6CF', '#8A5CFF', '#FF8B39', '#4AA8FF', '#F66BDE', '#A3E635'][n % 8] }"></i></div>
      </section>
    </div>
  </main>
</template>
