# Homelike 喜家居拉霸機

使用 Vue 3 + Vite，將 `初始.jpg` 作為底圖並對齊 `目標成品.jpg` 的互動元素。

## 啟動

```sh
npm install
npm run dev
```

`npm run build` 產生 `dist/`，`npm run preview` 可預覽正式建置。

## 遊戲規則

- 起始數字 168，每次等機率抽取 000～999（包含兩端），保留三位數。
- 填寫門市、顧客姓名並勾選消費確認後，按 READY TO PLAY! 解鎖拉桿，再按住拉桿往下拖曳開始抽獎（鍵盤可聚焦拉桿並按向下鍵）。
- 三輪依序停止，轉動期間禁止重複抽獎；完成後需再次按 READY TO PLAY! 解鎖才能再玩。
- 門市使用下拉選單，第一項留白，需選擇指定八間門市之一。
- 此版本為前端遊戲，不保存顧客資料或兌獎紀錄，也未限制每人抽獎次數。
- 數字 #2c394c；拉桿大圓 #E09C8B、小圓 #F0EED2；按鈕 #493C68、白色文字。

主要介面與抽獎邏輯在 `src/App.vue`，樣式在 `src/style.css`。

## 手機與平板

所有螢幕皆以 16:9 等比例顯示原版面，表單不另行移位。手機橫向可得到較大的操作畫面；直向時整體縮小。

## GitHub Pages

目標儲存庫：`homeliketw2005/solt-machine`，目標網址：`https://homeliketw2005.github.io/solt-machine/`。

將原始碼推送至 `main`，並在儲存庫 Settings → Pages 將 Source 設為 GitHub Actions。工作流程會自動建置並發布 `dist`。圖片與資源採相對路徑，支援專案子目錄。

目前已發布版本採用儲存庫 main 根目錄的獨立 index.html（內含 Vue、樣式與底圖），GitHub Pages Source 為 Deploy from a branch。儲存庫 vue-source.zip 提供 Vue 原始碼備份。
